from pyrandtoys.functions import dice
from pyrandtoys.functions import coin
from pyrandtoys.functions import dreidel
from pyrandtoys.functions import cat
from pyrandtoys.functions import switch
from pyrandtoys.functions import spinner
from pyrandtoys.functions import combi
from pyrandtoys.functions import card
